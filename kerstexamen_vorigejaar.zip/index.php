<?php include_once "../connect2db.inc";?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receptenboek</title>
    <link rel="stylesheet" href="style.css" type="text/css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
    <div class="w3-bar w3-teal w3-large w3-top">
        <span class="w3-bar-item">Receptenboek</span>
        <button class="w3-bar-item w3-button w3-light-gray w3-right link"><a class="link" href="add.php">nieuw</a></button>
    </div>
    <br>
    <br>
    <br>
    <br>
    <div class="w3-container">
   <?php
         $query = "SELECT * FROM Recept";
         $query .= " ORDER BY naam;";
         $recepten = mysqli_query($conn, $query) or die ("Fout in sql: $query");
    ?>
    <table class="w3-table w3-striped"> 
        <thead>
            <tr class="w3-light-grey">
                <th>naam</th>
                <th>aantal_personen</th>
                <th>bereidingswijze</th>
                <th>Ingredienten</th>
            </tr>
        </thead>
        <?php
            while ($recept=mysqli_fetch_array($recepten)) {
        ?>
        <tr>
            <td><?php echo $recept["naam"];?></td>
            <td><?php echo $recept["aantal_personen"]; ?></td>
            <td><?php echo $recept["bereidingswijze"];?></td>
        <td>
        <a class="link" href="edit.php?id=<?php echo $recept["id"]; ?>">✏️</a>
        <a class="link" href="delete.php?id=<?php echo $recept["id"]; ?>">🗑</a>
        </td>
        </tr>
    <?php
        }
    ?>
    </table>
    <br>
    <br>
    <br>
    </div>
    <div class="w3-bar w3-teal w3-bottom">
        <span class="w3-bar-item">(c) 2024 by Ka-Huan Ng</span>
    </div>
</body>
</html>
