<?php 
    include "../connect2db.inc";
        $naamIngredient=$_POST["frmNaamIngredient"];
        $hoeveelheid=$_POST["frmHoeveelheid"];
        $eenheid=$_POST["frmEenheid"];
        $query="INSERT INTO Ingrediënt (naam, hoeveelheid, eenheid) values ('$naamIngredient', '$hoeveelheid', '$eenheid');";
	$result=mysqli_query($conn,$query) or die("fout in sql!");
    header("Location: edit.php");
?>