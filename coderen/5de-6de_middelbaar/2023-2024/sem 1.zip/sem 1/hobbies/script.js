$(document).ready(function(){
    $("#buttonreadmore").click(function(){
        $(".readmore").css("display","block");
        $("#buttonreadmore").css("display","none");
    })
})