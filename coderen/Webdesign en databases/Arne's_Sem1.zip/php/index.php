<!DOCTYPE html>
<html>
<head>
<title>Oefeningen php</title>
</head>

<body>
    <h1>Oefening 1</h1>

   
    <?php
            echo "Ik kan tellen van 1 tot 10.";
    ?>
    

    

</body>
</html>