<!DOCTYPE html>
<html>
<head>
<title>Producten</title>
<head>

<body>
    <h1>Producten</h1>
    
    <table>
        <tr>
            <th>Naam</th>
            <th>Categorie</th>           
            <th>Prijs</th>           
            <th>Uitgiftedatum</th>
            
    
        </tr>
        <tr>
            <th>iPad 8 WiFi 32GB</th>
            <th>MacBook Pro 13-INCH M18GB 512GB</th>
            <th>USB-C-Oplaadkabel (1 M)</th>
        </tr>
        
        <tr>
            <th>tablet pc</th>           
            <th>laptop pc</th>
            <th>kabels</th>


        </tr>
        <tr>
            <th>389.00</th>
            <th>1679.00</th>
            <th>25.00</th>
        </tr>

        <tr>
            <th>2020-09-01</th>
            <th>0202-11-01</th>
            <th>2019-05-01</th>
        </tr>
        
    </table>
</body>
</html>