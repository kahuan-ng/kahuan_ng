<!DOCTYPE html>
<html>
    
<head>
    <title>W3.CSS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>

<body>
    <header class="w3-container w3-teal w3-top">
        <h1 class="w3-text-blue">Header</h1>
    </header>

    <br><br><br>

    <div class="w3-container">
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam vestibulum erat ut elit consectetur euismod. Phasellus sed nisi ut ligula ullamcorper commodo. Duis dapibus porta mauris sit amet rhoncus. Suspendisse potenti. Phasellus non pulvinar lorem, sit amet malesuada elit. Duis metus leo, aliquam at dignissim non, blandit iaculis elit. Aliquam facilisis pretium gravida. Proin ac sodales ligula, eleifend bibendum nisl. Nullam et orci rutrum, auctor nibh vitae, egestas augue. Nulla sed turpis erat. Vestibulum tempor ipsum eu ipsum tincidunt placerat. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Fusce condimentum dolor turpis, id posuere diam congue id. Sed augue arcu, consequat ac porta et, aliquam eu sem.

Cras sit amet euismod purus. Integer quam libero, eleifend non nisl a, tempus tincidunt elit. Nam varius iaculis leo, interdum dapibus ex pretium a. Integer a augue quis nisi tincidunt dapibus vitae ac sem. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Praesent tellus enim, consectetur at ultrices nec, vehicula eu tellus. Praesent faucibus ullamcorper efficitur.

Maecenas vitae posuere ex, non sagittis justo. Etiam ac odio et eros viverra tempus. Fusce enim purus, gravida ac porttitor vitae, auctor ac arcu. Interdum et malesuada fames ac ante ipsum primis in faucibus. Cras euismod elit eget risus volutpat, a iaculis eros luctus. Nunc facilisis augue purus, eget tempus dui finibus non. Proin non eros dolor. Pellentesque a massa accumsan sapien vulputate bibendum. Mauris vulputate arcu et laoreet rutrum. Praesent at tellus maximus, feugiat lorem eget, ornare ex. Sed tristique quis velit ut ultrices. Ut commodo eget tortor id tristique. Sed porttitor velit leo, sit amet imperdiet sapien sodales quis. Sed volutpat vitae risus vel rutrum.

Pellentesque luctus malesuada pellentesque. Ut mattis, leo eu pretium placerat, lorem tellus tristique risus, vitae ultrices justo orci non dui. Pellentesque rutrum non nisl vitae luctus. Donec rhoncus nunc at nisl congue, sit amet aliquet leo fringilla. Etiam nec tellus auctor libero dictum aliquam sit amet et turpis. Nam egestas pharetra diam cursus rutrum. Integer ac placerat metus. Cras risus tortor, efficitur ut ultricies sed, elementum euismod neque. Cras finibus erat sed nulla facilisis iaculis.

Maecenas turpis magna, facilisis at sem sit amet, luctus sollicitudin mauris. Nullam in commodo risus. Proin rutrum tortor tincidunt, fermentum lacus in, vulputate velit. Nunc interdum tincidunt ante laoreet vestibulum. Praesent eget fringilla eros. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ultricies ac risus ac ultricies. Nulla eu velit ultrices, fringilla tortor sit amet, viverra erat. Nam posuere bibendum fermentum. Integer et ante sed tortor convallis imperdiet. Aliquam fermentum metus odio, ut vestibulum orci ornare sed. Vivamus ex nisl, pulvinar vitae purus eu, elementum suscipit enim. Donec vel justo erat.

Nam varius enim sapien, id pharetra lectus feugiat vitae. Vivamus blandit elementum risus ut bibendum. Phasellus nec aliquet metus, eu pellentesque nisi. Donec convallis quis ante quis ultrices. Aliquam eget diam diam. Mauris laoreet sapien magna, sed rutrum ipsum tristique id. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In et urna lectus. Cras luctus nec neque quis pellentesque. Vestibulum posuere volutpat nulla. Duis mollis rhoncus urna. Aenean lectus orci, tristique eget purus quis, vulputate egestas ex. Praesent pharetra eget nibh quis aliquam. Proin suscipit ligula quis ex aliquam porta et interdum lacus. Nullam molestie vitae erat ut mollis. Vivamus ultricies purus vitae velit condimentum, vel volutpat justo posuere.

Duis blandit, dui in elementum faucibus, nunc quam elementum augue, sit amet ullamcorper mi nisi vel erat. Aliquam tincidunt risus sit amet massa viverra, id iaculis massa varius. Nulla rhoncus aliquam leo ut consectetur. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed a tristique purus. Nulla convallis urna et tortor condimentum, vel posuere libero mattis. Aliquam posuere diam sed ipsum tincidunt sodales. Curabitur lacus sem, congue at ligula in, tempus faucibus lacus.

Ut eu venenatis lorem, nec eleifend tellus. Cras sollicitudin sed augue eu vulputate. Vestibulum sit amet justo quis arcu tincidunt gravida ut sed libero. Nulla at efficitur magna. Ut luctus eros nisi, ut ultrices felis interdum a. Ut nunc urna, aliquam pharetra accumsan sit amet, dapibus vitae tortor. Vestibulum aliquam mauris quis accumsan pellentesque. Vestibulum malesuada felis ut dignissim feugiat. Vivamus cursus nibh nec arcu tempus lobortis at eget ante. Nulla quis lacinia nisl. Mauris eu consequat purus.

Morbi a ullamcorper odio, id imperdiet justo. Quisque nisl neque, dignissim a scelerisque id, vestibulum sit amet metus. Mauris eu elit et est eleifend tempus. Etiam accumsan scelerisque nibh, a luctus ligula convallis nec. Pellentesque sem ligula, mollis nec lacus nec, suscipit imperdiet enim. Duis vitae lacus in mi rhoncus gravida non ac odio. Nam consequat commodo justo, at volutpat metus blandit eu. Aenean volutpat sodales quam ut fringilla. Vivamus finibus ut orci eu elementum. Ut ante massa, elementum ut felis in, auctor aliquam nisi. Nulla facilisis quis turpis eu cursus. Nulla quam quam, vehicula non leo sed, porttitor egestas ex. Mauris fringilla volutpat turpis, in sodales mauris aliquet ac. Suspendisse eleifend ligula a velit porttitor elementum. Integer nec venenatis velit.

In vel enim mi. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Pellentesque varius justo nisi, eget malesuada elit commodo in. Ut ullamcorper porta odio, quis dapibus justo egestas vel. Maecenas sit amet ullamcorper neque, a iaculis lorem. Phasellus ullamcorper sed erat eu vehicula. Curabitur quis feugiat urna. Aenean dignissim justo porttitor orci accumsan rutrum.

Etiam sapien dui, malesuada finibus lectus non, vestibulum dignissim elit. Sed blandit massa eu posuere egestas. Sed eu augue id nisl ullamcorper convallis. Vestibulum non mi a sapien lacinia efficitur eget ac eros. Ut egestas commodo sapien a tempor. Etiam eu imperdiet purus. Nulla efficitur turpis sed nulla tristique dignissim. Suspendisse pretium vel nibh et tempor.

Sed risus ipsum, maximus sit amet maximus ac, convallis vel massa. Quisque convallis posuere libero non dignissim. Sed sit amet sollicitudin nisl. Curabitur egestas consectetur aliquam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed nec ornare lectus. Etiam accumsan, erat vitae accumsan congue, mi mi vestibulum orci, ac porta purus ex quis dolor. Nullam eu lacus quis leo mollis aliquam. Fusce pretium urna quis purus aliquam aliquet. Sed mollis, dolor sed tempor imperdiet, lectus tortor auctor dolor, non lobortis massa felis venenatis libero. Praesent sit amet ex sed mauris facilisis eleifend a in sem.

Etiam pretium egestas lacus, quis gravida massa finibus eu. Sed a blandit nibh. Cras nec pharetra enim. Vestibulum viverra cursus mauris. Duis erat magna, fermentum a vehicula et, tristique sit amet nunc. Aliquam erat volutpat. Pellentesque a ligula eget dolor porttitor aliquam. Donec commodo sem eu nibh porta vulputate et sed tortor. Duis consectetur iaculis tortor, non dapibus ex tristique eu. Suspendisse convallis velit ut nisl dictum porta. Pellentesque tellus nibh, dignissim non nibh vitae, condimentum feugiat risus. Praesent felis neque, convallis sed ante eu, pharetra venenatis augue.

Nulla auctor vestibulum nisl sit amet interdum. Sed ante velit, aliquet et massa tincidunt, placerat bibendum nunc. Fusce non tellus ligula. Duis a turpis pellentesque, interdum eros ut, consequat orci. Nullam commodo pretium nulla, id auctor metus facilisis vel. Praesent lobortis sodales diam. Ut est odio, lobortis non viverra sed, condimentum non sapien. Curabitur semper ligula est, quis luctus sapien vulputate ut. Donec dignissim et massa ac vehicula. Quisque venenatis felis id neque fringilla, et posuere tortor facilisis.

Nunc ornare nunc ut dolor cursus condimentum. Integer erat magna, sollicitudin sed purus ac, varius congue leo. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur commodo rutrum nisl. Phasellus congue, erat vitae tempor porttitor, lorem purus fermentum enim, eget posuere mauris elit ut urna. Fusce feugiat consectetur erat sed maximus. Vivamus tristique tristique nisi a condimentum. In quis tortor mauris. Mauris auctor tincidunt interdum.

Vivamus tempus tortor ut sem commodo, vel egestas odio dignissim. Quisque fermentum lacinia mi, non laoreet ex finibus in. In hac habitasse platea dictumst. Phasellus in eleifend velit. Fusce semper, nisl vel maximus tincidunt, ante mi pharetra nulla, in facilisis sem ex sit amet orci. Donec pellentesque diam lobortis lacus congue, maximus condimentum magna vehicula. Sed aliquam aliquet ipsum quis scelerisque. Praesent lorem justo, sollicitudin vitae purus a, imperdiet dictum felis. Vivamus luctus purus leo, non fermentum ex commodo non. Curabitur ut libero ac odio imperdiet pellentesque.

Donec in tincidunt dui. Aliquam sed mattis turpis. Ut maximus, metus vitae ullamcorper suscipit, lacus lorem dapibus mi, nec ultricies magna ipsum sed nisi. Nullam vel urna dapibus, scelerisque nunc vitae, condimentum lorem. Maecenas nisi augue, volutpat sit amet scelerisque nec, aliquam vitae lectus. Donec quis sagittis purus. Fusce dictum enim eget sodales imperdiet. Mauris scelerisque metus id lacinia consectetur. Pellentesque in mollis eros, a molestie arcu. Proin iaculis facilisis ullamcorper. Curabitur est felis, porttitor luctus accumsan tempor, ultricies vel justo. Quisque at ipsum vitae urna facilisis consequat. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Duis dapibus, velit tincidunt vehicula consequat, neque lorem accumsan felis, quis pharetra lectus quam non nunc. Mauris consectetur quis justo ac rutrum. Curabitur sit amet ex lacinia, lobortis nulla sit amet, convallis dolor.

Cras volutpat turpis in auctor ullamcorper. Maecenas porttitor consectetur velit ut accumsan. Sed a tristique risus. Donec egestas fermentum nibh, porttitor accumsan lorem eleifend non. Sed accumsan eleifend volutpat. Sed ipsum est, dictum accumsan ipsum eget, venenatis dignissim dolor. Sed purus elit, molestie quis condimentum ultricies, pellentesque nec erat. Nullam velit tellus, aliquam nec dui at, viverra pellentesque mi. Nullam eu risus tortor.

Donec quis eros sem. Donec aliquet magna ac orci semper, et egestas enim auctor. Proin interdum augue ut odio gravida, in lacinia purus auctor. Nulla et odio augue. Quisque cursus convallis dolor, id auctor enim cursus a. Suspendisse potenti. Integer porttitor faucibus sem, vel laoreet dui tincidunt ac. In commodo rhoncus auctor. Vivamus vitae molestie massa. Praesent scelerisque eros et tortor pulvinar consectetur. Integer auctor leo sed tortor congue, et mollis libero facilisis.

Praesent sagittis, eros sed tempus luctus, arcu ante bibendum dolor, commodo pellentesque lacus enim ut lorem. Praesent faucibus metus vitae erat consequat, vel pretium magna condimentum. Nunc eget quam diam. Proin ac nulla magna. Praesent ut quam interdum, volutpat augue eu, lacinia nulla. Donec convallis malesuada tempor. Nullam eleifend diam non leo scelerisque, ut dignissim nisl efficitur. Phasellus sed tellus semper, rhoncus magna vitae, consequat erat. Nam eget placerat dolor. Pellentesque a ipsum ut ligula vestibulum laoreet eu in orci.

    </p>
    </div>
    
<footer class="w3-container w3-orange w3-bottom">
  <h5>Footer</h5>
  <p>Footer information goes here</p>
    
</footer>
    

</body>
</html>